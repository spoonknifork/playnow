The Mailbox here has been shrunk, the real file size:

WC24RECV.MBX	0x00700000
WC24SEND.MBX	0x00200000
